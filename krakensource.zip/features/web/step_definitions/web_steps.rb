if ENV["ADB_DEVICE_ARG"].nil?
  require 'kraken-mobile/steps/web/kraken_steps'
  

  
end


When(
  /^I login using username="([^\"]*)" and password="([^\"]*)"$/
) do |username, password|
  raise 'ERROR: Invalid scenario tag' if @scenario_tags.nil?  
  raise 'ERROR: Invalid scenario tag' if username==nil?  
  raise 'ERROR: Invalid scenario tag' if password==nil?    
  
  @driver.find_element(:css,'#ember8').send_keys(username)
  @driver.find_element(:css,'#ember10').send_keys(password)
  
  @driver.find_element(:id, 'ember12').click
  sleep 5
end


Then(
  /^Verify that "([^\"]*)" has logged in$/
) do |userName|
  raise 'ERROR: Invalid scenario tag' if @scenario_tags.nil?  
  raise 'ERROR: Invalid scenario tag' if userName==nil?    
  
  
  foundElement=@driver.find_element(:css,'.gh-user-email')    
  textFound =  foundElement.text()      
  raise 'ERROR: Invalid scenario tag' if  ( textFound.index(userName)   ) != 0
  
end

When(
  /^I go to new tags page$/
) do 

  url = @driver.current_url;
  url["site"]="tags/new"
  print 'URL:' + url
  @driver.navigate.to url
  sleep 5
end

When(
  /^I enter "([^\"]*)" into tag name field$/
) do |textToFill|

  @driver.find_element(:id,'tag-name').send_keys(textToFill)
  sleep 5
end


Then(
  /^I should be able to save a tag$/
) do

  @driver.find_element(:css, '.gh-canvas-header button').click
  sleep 1
  @driver.page_source.include?("Saved")
  
end

Then(
  /^I should not be able to save a tag$/
) do 

  @driver.find_element(:css, '.gh-canvas-header button').click
  sleep 1
  @driver.page_source.include?("Retry")
  
end


When(
  /^I go to staff page$/
) do 

  url = @driver.current_url;
  url["site"]="staff"
  print 'URL:' + url
  @driver.navigate.to url
  sleep 5
end


When(
  /^I click on Invite People$/
) do 

  @driver.find_element(:css, '.gh-btn-green').click
  sleep 5
end


When(
  /^I enter "([^\"]*)" into email address field$/
) do |email|
 
  @driver.find_element(:css, '.modal-footer button').click
  sleep 2
  @driver.find_element(:id,'new-user-email').send_keys(email)
  sleep 5
  
end

Then(
  /^I should be able to send invitation$/
) do

  @driver.find_element(:css, '.modal-footer button').click
  sleep 5
  pageS=@driver.page_source
  
  raise 'ERROR: Invalid scenario ' if (pageS.index('Invite a New User') != nil )
  
  sleep 5
  
end


Then(
  /^I should not be able to send invitation$/
) do


  @driver.page_source.include?("Please enter an email.")
  sleep 5
  
end

When(
  /^I go to design page$/
) do 

  url = @driver.current_url;
  url["site"]="settings/design"
  print 'URL:' + url
  @driver.navigate.to url
  sleep 5
end

When(
  /^I enter "([^\"]*)" on label field$/
) do |label|

  elements=@driver.find_elements(:css, '#settings-navigation input')
  labelInput=elements[elements.length()-2]
  labelInput.send_keys(label)
  sleep 2
  
end


Then(
  /^I should be able to add new navigation item$/
) do 

	@driver.find_element(:css, '.gh-canvas-header button').click
	sleep 2
	@driver.page_source.include?("Saved")
	sleep 2
  
end



Then(
  /^I should not be able to add new navigation item$/
) do 

	@driver.find_element(:css, '#settings-navigation .gh-blognav-add').click
	sleep 2
	@driver.page_source.include?("You must specify a label")
	sleep 5
  
end


When(
  /^I navigate to active user profile page$/
) do 

  @driver.find_element(:css, '.gh-nav-bottom .ember-basic-dropdown-trigger').click
	sleep 2
	@driver.find_element(:partial_link_text, 'Profile').click
	sleep 2
	
end

Then(
  /^I should be able to save with all information populated$/
) do 

	@driver.find_element(:css, '.gh-canvas-header button').click
	sleep 2
	@driver.page_source.include?("Saved")
	sleep 5
  
end

Then(
  /^I should not be able to save without email$/
) do 

	@driver.find_element(:css, '#user-email').clear
	sleep 2	
	@driver.find_element(:css, '#user-email').send_keys('EMPTY')	
	sleep 2
	@driver.find_element(:css, '#user-email').send_keys :tab
	sleep 2
	@driver.find_element(:css, '.gh-canvas-header button').click
	sleep 2
	@driver.page_source.include?("Retry")
	sleep 5
  
end