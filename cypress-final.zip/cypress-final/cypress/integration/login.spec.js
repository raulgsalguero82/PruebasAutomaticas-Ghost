describe('Testing Login Feature', () => {
	beforeEach(() => {
		cy.visit('http://localhost:2368/ghost/#/signin')
		cy.wait(3000)
	})

	it('should login correctly', () => {
		cy.get('form').within(() => {
			cy.get('input[name="identification"]').type('example@example.com')
			cy.get('input[name="password"]').type('cypress-final')
			cy.get('button.login.gh-btn.gh-btn-blue').click({ force: true })
		})

		cy.wait(3000)
		cy.get('span.gh-user-email').scrollIntoView().should('be.visible')
	})

	it('should return error when password is incorrect', () => {
		cy.get('form').within(() => {
			cy.get('input[name="identification"]').type('example@example.com')
			cy.get('input[name="password"]').type('test123456903323')
			cy.get('button.login.gh-btn.gh-btn-blue').click({ force: true })
		})
		cy.wait(3000)
		cy.get('p.main-error').scrollIntoView().should('be.visible')
	})
})
